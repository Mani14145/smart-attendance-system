/**
 * Expo App placeholder.
 * Screens: Login -> TeacherDashboard / StudentScanner
 * Fill components in /src to implement QR scanning, geofence, face capture.
 */
import React from 'react';
import { Text, View } from 'react-native';

export default function App() {
  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
      <Text>Smart Attendance App (scaffold) — implement screens in /src</Text>
    </View>
  );
}
