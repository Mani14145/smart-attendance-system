import React from 'react';
import { View, Text } from 'react-native';

export default function TeacherDashboard(){
  return (<View><Text>Teacher Dashboard placeholder</Text></View>);
}
