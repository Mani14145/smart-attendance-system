// TODO: Implement geofencing checks using expo-location and distance calculations
