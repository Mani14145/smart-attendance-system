// TODO: Implement QR scanning using expo-barcode-scanner and validate QR payload
