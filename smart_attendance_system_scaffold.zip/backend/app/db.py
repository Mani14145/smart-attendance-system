"""MongoDB client (motor) placeholder"""
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseSettings
import os

MONGO_URI = os.getenv('MONGO_URI', 'mongodb://localhost:27017/smart_attendance')
client = AsyncIOMotorClient(MONGO_URI)
db = client.get_default_database()
