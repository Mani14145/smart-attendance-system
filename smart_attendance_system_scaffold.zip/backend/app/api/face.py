# Face encoding and verification endpoints (placeholders)
from fastapi import APIRouter, UploadFile, File

router = APIRouter(prefix='/face', tags=['face'])

@router.post('/enroll')
async def enroll_face(student_id: str, file: UploadFile = File(...)):
    """Accept image, generate encoding, store as base64 in MongoDB collection."""
    return {"msg":"enroll placeholder"}

@router.post('/verify')
async def verify_face(student_id: str, file: UploadFile = File(...)):
    """Return verification result true/false and score."""
    return {"verified": False, "score": 0.0}
