# Endpoints for creating sessions and marking attendance (placeholders)
from fastapi import APIRouter, HTTPException

router = APIRouter(prefix='/attendance', tags=['attendance'])

@router.post('/create')
async def create_session():
    return {"msg":"create session placeholder"}

@router.post('/mark')
async def mark_attendance():
    # Expected flow: verify QR payload -> geofence check -> face verification -> mark attendance
    raise HTTPException(status_code=501, detail="Not implemented: mark attendance pipeline")
