from fastapi import APIRouter
router = APIRouter(prefix='/student', tags=['student'])

@router.get('/me')
async def me(student_id: str):
    return {"student": {"id": student_id}}
