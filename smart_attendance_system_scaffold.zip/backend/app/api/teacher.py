from fastapi import APIRouter
router = APIRouter(prefix='/teacher', tags=['teacher'])

@router.get('/sessions')
async def list_sessions(teacher_id: str):
    return {"sessions": []}
