# TODO: implement authentication endpoints (JWT / simple token)
from fastapi import APIRouter

router = APIRouter(prefix='/auth', tags=['auth'])

@router.post('/login')
async def login():
    return {"msg":"login placeholder"}
