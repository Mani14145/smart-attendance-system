from pydantic import BaseModel, Field
from typing import Optional

class UserBase(BaseModel):
    name: str
    email: str

class Student(UserBase):
    student_id: str

class Teacher(UserBase):
    teacher_id: str
