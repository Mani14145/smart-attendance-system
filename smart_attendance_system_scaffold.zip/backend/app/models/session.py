from pydantic import BaseModel
from typing import List

class AttendanceSession(BaseModel):
    session_id: str
    teacher_id: str
    geofence: dict  # {lat, lng, radius_meters}
    start_time: str
    end_time: str
    qr_payload: str
