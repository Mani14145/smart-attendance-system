"""Utility to generate QR payload for a session (placeholder).

Suggested payload: {session_id, teacher_id, expiry_ts, geofence:{lat,lng,radius}, signature}
Sign using QR_SECRET to prevent tampering.
"""
def generate_payload(session_id, teacher_id, geofence, expiry_ts):
    return {"session_id":session_id, "teacher_id":teacher_id, "geofence":geofence, "expiry":expiry_ts}
