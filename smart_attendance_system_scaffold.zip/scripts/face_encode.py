"""Outline for face encoding pipeline:
- Accept image path(s)
- Use face_recognition.load_image_file + face_recognition.face_encodings
- Store encoding (list of floats) as base64/JSON in MongoDB
"""
