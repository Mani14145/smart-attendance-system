# Deployment notes

- Use Docker Compose for dev. For production, split services and use managed MongoDB.
- Use HTTPS (Let's Encrypt) and secure CORS origins.
- Face encodings are sensitive — protect DB access and rotate keys used for QR signing.
