# Architecture Overview

Components:
- Expo mobile app (students & teachers)
- FastAPI backend (APIs: auth, sessions, face)
- MongoDB (stores users, sessions, encodings, attendance records)
- Optional: Nginx reverse proxy, SSL termination

Flow:
1. Teacher creates session -> backend stores session + geofence -> backend returns signed QR payload
2. Student scans QR -> app reads QR payload -> sends to backend with current GPS coords and face capture
3. Backend verifies geofence and face -> marks attendance in DB
