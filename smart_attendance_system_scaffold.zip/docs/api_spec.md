# API Spec (summary)

## POST /auth/login
- body: {email, password}
- returns: token

## POST /attendance/create
- body: {teacher_id, geofence: {lat,lng,radius}, start_time, end_time}
- returns: {session_id, qr_payload}

## POST /attendance/mark
- multipart: qr_payload, image(file), lat, lng, student_id
- response: {marked: true/false, reason: 'geofence_fail'|'face_mismatch'|'ok'}

## POST /face/enroll
- multipart: student_id, image(file)
- action: generate encoding and store

## POST /face/verify
- multipart: student_id, image(file)
- action: compare encoding with stored and return score
