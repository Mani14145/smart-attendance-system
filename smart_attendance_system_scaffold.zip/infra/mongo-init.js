// MongoDB init script (runs once in container startup)
db = db.getSiblingDB('smart_attendance');
db.createCollection('users');
db.createCollection('attendance_sessions');
db.createCollection('face_encodings');
